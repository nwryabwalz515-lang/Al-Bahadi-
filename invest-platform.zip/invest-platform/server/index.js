require('dotenv').config();
const express = require('express');
const cors = require('cors');
const pool = require('./db');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const slugify = require('slugify');
const fs = require('fs');

const authRoutes = require('./routes/auth');
const projectsRoutes = require('./routes/projects');
const investmentsRoutes = require('./routes/investments');

const app = express();
app.use(cors());
app.use(express.json());

app.use('/api/auth', authRoutes);
app.use('/api/projects', projectsRoutes);
app.use('/api/invest', investmentsRoutes);

app.get('/', (req, res) => res.json({ ok: true, message: 'Invest Platform API' }));

const PORT = process.env.PORT || 4000;
app.listen(PORT, async () => {
  console.log('Server listening on', PORT);
  // تأكد من وجود الجداول (تنفيذ init_db.sql عند الاقتضاء)
  try {
    const initSql = fs.readFileSync(__dirname + '/migrations/init.sql', 'utf8');
    await pool.query(initSql);
    console.log('DB initialized');
  } catch (err) {
    console.warn('DB init warning:', err.message);
  }
});
