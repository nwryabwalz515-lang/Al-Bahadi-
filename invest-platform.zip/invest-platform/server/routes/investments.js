const express = require('express');
const router = express.Router();
const pool = require('../db');

// تنفيذ استثمار (بشكل مبسط: يقوم بخصم من المحفظة الداخلية وتسجيل الاستثمار)
router.post('/:projectId', async (req, res) => {
  const { projectId } = req.params;
  const { user_id, amount } = req.body; // في الواقع تأخذ من التوكن
  if (!user_id || !amount) return res.status(400).json({ error: 'missing fields' });

  try {
    await pool.query('BEGIN');
    // تحقق الرصيد
    const w = await pool.query('SELECT * FROM wallets WHERE user_id=$1 FOR UPDATE', [user_id]);
    if (!w.rowCount) {
      await pool.query('ROLLBACK');
      return res.status(400).json({ error: 'wallet not found' });
    }
    const wallet = w.rows[0];
    if (parseFloat(wallet.balance) < parseFloat(amount)) {
      await pool.query('ROLLBACK');
      return res.status(400).json({ error: 'insufficient funds' });
    }
    // خصم من المحفظة
    await pool.query('UPDATE wallets SET balance = balance - $1, updated_at = NOW() WHERE user_id=$2', [amount, user_id]);
    // تسجيل المعاملة
    await pool.query('INSERT INTO transactions (user_id, type, amount, status) VALUES ($1,$2,$3,$4)', [user_id, 'investment', amount, 'completed']);
    // تسجيل الاستثمار
    const inv = await pool.query('INSERT INTO investments (user_id, project_id, amount, status) VALUES ($1,$2,$3,$4) RETURNING *', [user_id, projectId, amount, 'confirmed']);
    // تحديث مبلغ المشروع المستثمر
    await pool.query('UPDATE projects SET invested_amount = invested_amount + $1 WHERE id=$2', [amount, projectId]);

    await pool.query('COMMIT');
    res.json({ investment: inv.rows[0] });
  } catch (err) {
    await pool.query('ROLLBACK');
    console.error(err);
    res.status(500).json({ error: 'server error' });
  }
});

module.exports = router;
