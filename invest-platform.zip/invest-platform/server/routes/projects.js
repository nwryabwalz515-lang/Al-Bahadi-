const express = require('express');
const router = express.Router();
const pool = require('../db');
const slugify = require('slugify');

// قائمة المشاريع
router.get('/', async (req, res) => {
  const q = await pool.query('SELECT id, title, short_description, target_amount, invested_amount, status FROM projects ORDER BY created_at DESC');
  res.json(q.rows);
});

// تفاصيل مشروع
router.get('/:id', async (req, res) => {
  const { id } = req.params;
  const q = await pool.query('SELECT * FROM projects WHERE id=$1', [id]);
  if (!q.rowCount) return res.status(404).json({ error: 'not found' });
  res.json(q.rows[0]);
});

// إنشاء مشروع (ببساطة - يفترض issuer أو admin، هنا تجاهل auth للتحبيب)
router.post('/', async (req, res) => {
  const { company_id, title, short_description, description, target_amount, min_investment, expected_return_percent, duration_months } = req.body;
  try {
    const slug = slugify(title, { lower: true });
    const q = await pool.query(
      `INSERT INTO projects (company_id, title, slug, short_description, description, sector, target_amount, min_investment, expected_return_percent, duration_months)
       VALUES ($1,$2,$3,$4,$5,'general',$6,$7,$8,$9) RETURNING *`,
      [company_id, title, slug, short_description, description, target_amount, min_investment, expected_return_percent, duration_months]
    );
    res.json(q.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'server error' });
  }
});

module.exports = router;
