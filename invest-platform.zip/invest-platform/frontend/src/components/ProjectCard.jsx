import React from 'react'
export default function ProjectCard({project}){
  return (
    <div className="p-3 border rounded">
      <h3 className="font-semibold">{project.title}</h3>
      <p className="text-sm">{project.short_description}</p>
      <div className="mt-2 text-xs">مطلوب: {project.target_amount} — المستثمر: {project.invested_amount}</div>
    </div>
  )
}
