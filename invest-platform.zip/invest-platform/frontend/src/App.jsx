import React from 'react'
import { Outlet, Link } from 'react-router-dom'
export default function App(){
  return (
    <div className="p-4 font-sans">
      <header className="mb-6">
        <h1 className="text-2xl font-bold">منصة استثمار - Demo</h1>
        <nav>
          <Link to="/">المشاريع</Link> | <Link to="/auth">دخول / تسجيل</Link>
        </nav>
      </header>
      <main>
        <Outlet />
      </main>
    </div>
  )
}
