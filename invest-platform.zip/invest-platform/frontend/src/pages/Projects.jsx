import React, { useEffect, useState } from 'react';
import api from '../api';
import ProjectCard from '../components/ProjectCard';

export default function Projects(){
  const [projects, setProjects] = useState([]);
  useEffect(()=>{
    api.get('/projects').then(r=>setProjects(r.data)).catch(e=>console.error(e));
  },[]);
  return (
    <div>
      <h2 className="text-xl mb-4">المشاريع المتاحة</h2>
      <div className="grid gap-3">
        {projects.map(p => <ProjectCard key={p.id} project={p} />)}
      </div>
    </div>
  )
}
