import React, { useState } from 'react';
import api from '../api';

export default function Auth(){
  const [mode, setMode] = useState('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const handleRegister = async ()=>{
    try{
      const r = await api.post('/auth/register', { email, password, full_name: name });
      alert('Registered ' + r.data.user.email);
    }catch(e){ alert('error') }
  }
  const handleLogin = async ()=>{
    try{
      const r = await api.post('/auth/login', { email, password });
      localStorage.setItem('token', r.data.token);
      alert('Welcome ' + r.data.user.full_name);
    }catch(e){ alert('login failed') }
  }

  return (
    <div className="max-w-md">
      <div className="mb-4">
        <button onClick={()=>setMode('login')}>دخول</button>
        <button onClick={()=>setMode('register')}>تسجيل</button>
      </div>
      {mode === 'register' && (
        <div>
          <input placeholder="الاسم" value={name} onChange={e=>setName(e.target.value)} />
          <input placeholder="البريد" value={email} onChange={e=>setEmail(e.target.value)} />
          <input placeholder="كلمة المرور" value={password} onChange={e=>setPassword(e.target.value)} />
          <button onClick={handleRegister}>سجل</button>
        </div>
      )}
      {mode === 'login' && (
        <div>
          <input placeholder="البريد" value={email} onChange={e=>setEmail(e.target.value)} />
          <input placeholder="كلمة المرور" value={password} onChange={e=>setPassword(e.target.value)} />
          <button onClick={handleLogin}>دخول</button>
        </div>
      )}
    </div>
  )
}
